import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:jidoapp/models/country_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

// JSON 파싱을 위한 최상위 함수 (compute에서 사용)
List<Country> _parseAndFilterCountries(String jsonStr) {
  final data = json.decode(jsonStr);
  final List<dynamic> features = data['features'];
  List<Country> countries = features.map((feature) => Country.fromJson(feature)).toList();
  // 'Indian Ocean Territories' 데이터 제거
  countries.removeWhere((country) => country.name.toLowerCase() == 'indian ocean ter.');
  return countries;
}

class CountryProvider with ChangeNotifier {
  bool _isLoading = true;
  List<Country> _allCountries = [];
  Set<String> _visitedCountries = {};

  bool get isLoading => _isLoading;
  List<Country> get allCountries => _allCountries;
  Set<String> get visitedCountries => _visitedCountries;

  CountryProvider() {
    _initializeData();
  }

  Future<void> _initializeData() async {
    // 1. JSON 파일 로드 및 파싱
    final String jsonStr = await rootBundle.loadString('assets/custom.geo.json');
    _allCountries = await compute(_parseAndFilterCountries, jsonStr);

    // 2. 저장된 방문 국가 목록 로드
    final prefs = await SharedPreferences.getInstance();
    _visitedCountries = prefs.getStringList('visited_countries')?.toSet() ?? {};

    // 3. 모든 데이터 준비 완료, 로딩 상태 해제 및 UI 업데이트 알림
    _isLoading = false;
    notifyListeners();
  }

  void updateVisitedCountries(Set<String> newCountries) {
    _visitedCountries = newCountries;
    _saveVisitedCountries();
    notifyListeners();
  }

  Future<void> _saveVisitedCountries() async {
    final prefs = await SharedPreferences.getInstance();
    // *** 중요: _visitedCountries(Set)를 .toList()로 변환하여 저장 ***
    await prefs.setStringList('visited_countries', _visitedCountries.toList());
  }
}