import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class Country {
  final String name;
  final String? continent;
  final String? subregion;
  // *** 중요: 국가의 폴리곤 데이터를 올바른 구조로 저장하도록 변경 ***
  // 구조: [폴리곤1, 폴리곤2, ...], 각 폴리곤 = [외곽선 링, 구멍 링1, 구멍 링2, ...], 각 링 = [LatLng 점1, LatLng 점2, ...]
  final List<List<List<LatLng>>> polygonsData;

  Country({
    required this.name,
    this.continent,
    this.subregion,
    required this.polygonsData,
  });

  factory Country.fromJson(Map<String, dynamic> json) {
    final properties = json['properties'];
    final geometry = json['geometry'];
    final coordinates = geometry['coordinates'];
    final type = geometry['type'];

    List<List<List<LatLng>>> allPolygonsData = [];

    // 좌표(List<dynamic>)를 LatLng 객체의 리스트(List<LatLng>)로 변환하는 함수
    List<LatLng> coordsToLatLng(List coords) {
      return coords
          .map((coord) => LatLng(coord[1].toDouble(), coord[0].toDouble()))
          .toList();
    }

    if (type == 'Polygon') {
      // 타입이 'Polygon'인 경우, 하나의 폴리곤 데이터를 리스트에 추가
      List<List<LatLng>> polygonRings = [];
      for (var ring in coordinates) {
        polygonRings.add(coordsToLatLng(ring));
      }
      allPolygonsData.add(polygonRings);

    } else if (type == 'MultiPolygon') {
      // 타입이 'MultiPolygon'인 경우, 여러 폴리곤 데이터를 각각 처리하여 리스트에 추가
      for (var polygon in coordinates) {
        List<List<LatLng>> polygonRings = [];
        for (var ring in polygon) {
          polygonRings.add(coordsToLatLng(ring));
        }
        allPolygonsData.add(polygonRings);
      }
    }

    return Country(
      name: properties['admin'] ?? properties['name'] ?? 'Unknown',
      continent: properties['continent'],
      subregion: properties['subregion'],
      polygonsData: allPolygonsData,
    );
  }
}