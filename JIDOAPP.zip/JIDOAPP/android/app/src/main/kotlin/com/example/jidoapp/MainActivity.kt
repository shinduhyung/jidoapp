package com.example.jidoapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
